package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Loja;
import util.Conexao;

public class PLoja {

    Connection conn;

    // INSERIR
    public void inserir(Loja l){

        String sql =
        "INSERT INTO loja(nome, cidade, gerente, ativa) VALUES(?,?,?,?)";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1, l.getNome());

            ps.setString(2, l.getCidade());

            ps.setString(3, l.getGerente());

            ps.setBoolean(4, l.isAtiva());

            ps.execute();

        }catch(Exception e){

            System.out.println(e);

        }

    }

    // LISTAR
    public ArrayList<Loja> listar(){

        ArrayList<Loja> lista =
                new ArrayList<>();

        String sql =
                "SELECT * FROM loja";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                Loja l = new Loja();

                l.setId(rs.getInt("id"));

                l.setNome(rs.getString("nome"));

                l.setCidade(rs.getString("cidade"));

                l.setGerente(rs.getString("gerente"));

                l.setAtiva(rs.getBoolean("ativa"));

                lista.add(l);

            }

        }catch(Exception e){

            System.out.println(e);

        }

        return lista;

    }

}