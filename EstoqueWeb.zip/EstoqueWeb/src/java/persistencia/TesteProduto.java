package persistencia;

import java.util.ArrayList;
import model.Produto;

public class TesteProduto {

    public static void main(String[] args) {

        PProduto dao = new PProduto();

        ArrayList<Produto> lista = dao.listar();

        for (Produto p : lista) {

            System.out.println("ID: " + p.getId());
            System.out.println("Nome: " + p.getNome());
            System.out.println("Categoria: " + p.getCategoria());
            System.out.println("Quantidade: " + p.getQuantidade());
            System.out.println("Preço: " + p.getPreco());

            System.out.println("-------------------");
        }
    }
}