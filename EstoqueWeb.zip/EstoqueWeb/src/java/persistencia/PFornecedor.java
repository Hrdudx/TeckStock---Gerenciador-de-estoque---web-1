package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Fornecedor;
import util.Conexao;

public class PFornecedor {

    Connection conn;

    // INSERIR
    public void inserir(Fornecedor f){

        String sql =
        "INSERT INTO fornecedor(nome, empresa, telefone, email) VALUES(?,?,?,?)";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1, f.getNome());

            ps.setString(2, f.getEmpresa());

            ps.setString(3, f.getTelefone());

            ps.setString(4, f.getEmail());

            ps.execute();

        }catch(Exception e){

            System.out.println(e);

        }

    }

    // LISTAR
    public ArrayList<Fornecedor> listar(){

        ArrayList<Fornecedor> lista =
                new ArrayList<>();

        String sql =
                "SELECT * FROM fornecedor";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                Fornecedor f =
                        new Fornecedor();

                f.setId(rs.getInt("id"));

                f.setNome(
                    rs.getString("nome")
                );

                f.setEmpresa(
                    rs.getString("empresa")
                );

                f.setTelefone(
                    rs.getString("telefone")
                );

                f.setEmail(
                    rs.getString("email")
                );

                lista.add(f);

            }

        }catch(Exception e){

            System.out.println(e);

        }

        return lista;

    }

}