package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Produto;
import util.Conexao;
import java.sql.ResultSet;

public class PProduto {

    Connection conn;

    // INSERIR PRODUTO
    public void inserir(Produto p) {

        String sql =
                "INSERT INTO produto(nome, categoria, quantidade, preco) "
                + "VALUES (?, ?, ?, ?)";

        try {

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1, p.getNome());
            ps.setString(2, p.getCategoria());
            ps.setInt(3, p.getQuantidade());
            ps.setDouble(4, p.getPreco());

            ps.execute();

            System.out.println("Produto cadastrado!");

        } catch (Exception e) {

            System.out.println("Erro inserir: " + e);

        }
    }

    // LISTAR PRODUTOS
    public ArrayList<Produto> listar() {

        ArrayList<Produto> lista =
                new ArrayList<>();

        String sql = "SELECT * FROM produto";

        try {

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Produto p = new Produto();

                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setCategoria(rs.getString("categoria"));
                p.setQuantidade(rs.getInt("quantidade"));
                p.setPreco(rs.getDouble("preco"));

                lista.add(p);
            }

        } catch (Exception e) {

            System.out.println("Erro listar: " + e);

        }

        return lista;
    }
        // EXCLUIR PRODUTO
    public void excluir(int id){

        String sql =
                "DELETE FROM produto WHERE id=?";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.execute();

            System.out.println("Produto excluído!");

        }catch(Exception e){

            System.out.println(
                    "Erro excluir: " + e
            );

        }

    }
        // ALTERAR PRODUTO
    public void alterar(Produto p){

        String sql =
        "UPDATE produto SET nome=?, categoria=?, quantidade=?, preco=? WHERE id=?";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1, p.getNome());

            ps.setString(2, p.getCategoria());

            ps.setInt(3, p.getQuantidade());

            ps.setDouble(4, p.getPreco());

            ps.setInt(5, p.getId());

            ps.execute();

            System.out.println(
                    "Produto alterado!"
            );

        }catch(Exception e){

            System.out.println(
                    "Erro alterar: " + e
            );

        }

    }
        // BUSCAR PRODUTO
    public ArrayList<Produto> buscar(String nome){

        ArrayList<Produto> lista =
                new ArrayList<>();

        String sql =
        "SELECT * FROM produto WHERE nome ILIKE ?";

        try{

            conn = Conexao.getConexao();

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1,
                    "%" + nome + "%");

            ResultSet rs =
                    ps.executeQuery();

            while(rs.next()){

                Produto p = new Produto();

                p.setId(rs.getInt("id"));

                p.setNome(
                    rs.getString("nome")
                );

                p.setCategoria(
                    rs.getString("categoria")
                );

                p.setQuantidade(
                    rs.getInt("quantidade")
                );

                p.setPreco(
                    rs.getDouble("preco")
                );

                lista.add(p);

            }

        }catch(Exception e){

            System.out.println(e);

        }

        return lista;

    }
}
