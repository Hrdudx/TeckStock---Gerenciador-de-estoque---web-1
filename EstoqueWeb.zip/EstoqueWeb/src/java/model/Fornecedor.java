package model;

public class Fornecedor {

    private int id;

    private String nome;

    private String empresa;

    private String telefone;

    private String email;

    // GET ID
    public int getId(){

        return id;

    }

    // SET ID
    public void setId(int id){

        this.id = id;

    }

    // GET NOME
    public String getNome(){

        return nome;

    }

    // SET NOME
    public void setNome(String nome){

        this.nome = nome;

    }

    // GET EMPRESA
    public String getEmpresa(){

        return empresa;

    }

    // SET EMPRESA
    public void setEmpresa(String empresa){

        this.empresa = empresa;

    }

    // GET TELEFONE
    public String getTelefone(){

        return telefone;

    }

    // SET TELEFONE
    public void setTelefone(String telefone){

        this.telefone = telefone;

    }

    // GET EMAIL
    public String getEmail(){

        return email;

    }

    // SET EMAIL
    public void setEmail(String email){

        this.email = email;

    }

}