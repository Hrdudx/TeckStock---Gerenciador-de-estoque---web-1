package model;

public class Loja {

    private int id;
    private String nome;
    private String cidade;
    private String gerente;
    private boolean ativa;

    public Loja() {
    }

    public Loja(int id, String nome,
            String cidade,
            String gerente,
            boolean ativa) {

        this.id = id;
        this.nome = nome;
        this.cidade = cidade;
        this.gerente = gerente;
        this.ativa = ativa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getGerente() {
        return gerente;
    }

    public void setGerente(String gerente) {
        this.gerente = gerente;
    }

    public boolean isAtiva() {
        return ativa;
    }

    public void setAtiva(boolean ativa) {
        this.ativa = ativa;
    }
}