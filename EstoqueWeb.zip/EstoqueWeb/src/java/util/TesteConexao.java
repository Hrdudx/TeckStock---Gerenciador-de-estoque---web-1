package util;

import util.Conexao;

public class TesteConexao {

    public static void main(String[] args) {

        Conexao.getConexao();

    }
}