package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

    public static Connection getConexao() {

        Connection conn = null;

        try {

            Class.forName("org.postgresql.Driver");

            conn = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/estoque",
                    "postgres",
                    "Rocha2005*"
            );

            System.out.println("Conectado com sucesso!");

        } catch (Exception e) {

            System.out.println("Erro na conexão: " + e);

        }

        return conn;
    }
}