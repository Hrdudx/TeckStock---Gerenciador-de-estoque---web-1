package controller;

import java.util.ArrayList;
import model.Produto;
import negocio.NProduto;

public class CProduto {

    NProduto negocio = new NProduto();

    // INSERIR
    public void inserir(Produto p){

        negocio.inserir(p);

    }

    // LISTAR
    public ArrayList<Produto> listar(){

        return negocio.listar();

    }
        // EXCLUIR
    public void excluir(int id){

        negocio.excluir(id);

    }
        // ALTERAR
    public void alterar(Produto p){

        negocio.alterar(p);

    }
        // BUSCAR
    public ArrayList<Produto> buscar(String nome){

        return negocio.buscar(nome);

    }

}