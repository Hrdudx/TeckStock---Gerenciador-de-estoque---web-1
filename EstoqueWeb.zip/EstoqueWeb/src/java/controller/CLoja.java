package controller;

import java.util.ArrayList;
import model.Loja;
import negocio.NLoja;

public class CLoja {

    NLoja negocio =
            new NLoja();

    public void inserir(Loja l){

        negocio.inserir(l);

    }

    public ArrayList<Loja> listar(){

        return negocio.listar();

    }

}