package controller;

import java.util.ArrayList;
import model.Fornecedor;
import negocio.NFornecedor;

public class CFornecedor {

    NFornecedor negocio =
            new NFornecedor();

    public void inserir(Fornecedor f){

        negocio.inserir(f);

    }

    public ArrayList<Fornecedor> listar(){

        return negocio.listar();

    }

}