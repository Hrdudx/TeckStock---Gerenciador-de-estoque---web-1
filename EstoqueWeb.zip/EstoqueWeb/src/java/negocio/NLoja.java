package negocio;

import java.util.ArrayList;
import model.Loja;
import persistencia.PLoja;

public class NLoja {

    PLoja persistencia =
            new PLoja();

    public void inserir(Loja l){

        persistencia.inserir(l);

    }

    public ArrayList<Loja> listar(){

        return persistencia.listar();

    }

}