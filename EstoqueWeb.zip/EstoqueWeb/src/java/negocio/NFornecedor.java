package negocio;

import java.util.ArrayList;
import model.Fornecedor;
import persistencia.PFornecedor;

public class NFornecedor {

    PFornecedor persistencia =
            new PFornecedor();

    public void inserir(Fornecedor f){

        persistencia.inserir(f);

    }

    public ArrayList<Fornecedor> listar(){

        return persistencia.listar();

    }

}