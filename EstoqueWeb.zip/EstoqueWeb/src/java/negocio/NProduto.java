package negocio;

import java.util.ArrayList;
import model.Produto;
import persistencia.PProduto;

public class NProduto {

    PProduto persistencia = new PProduto();

    // INSERIR
    public void inserir(Produto p){

        persistencia.inserir(p);

    }

    // LISTAR
    public ArrayList<Produto> listar(){

        return persistencia.listar();

    }
        // EXCLUIR
    public void excluir(int id){

        persistencia.excluir(id);

    }
        // ALTERAR
    public void alterar(Produto p){

        persistencia.alterar(p);

    }
        // BUSCAR
    public ArrayList<Produto> buscar(String nome){

        return persistencia.buscar(nome);

    }

}