<%@page import="java.util.ArrayList"%>
<%@page import="model.Produto"%>
<%@page import="controller.CProduto"%>

<%

    CProduto controller =
            new CProduto();

    String pesquisa =
            request.getParameter("pesquisa");

    ArrayList<Produto> lista;

    if(pesquisa != null &&
       !pesquisa.equals("")){

        lista =
            controller.buscar(pesquisa);

    }else{

        lista =
            controller.listar();

    }

%>

<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="Content-Type"
          content="text/html; charset=UTF-8">

    <title>TechStock Inform�tica</title>

    <style>

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body{

            font-family: Arial, Helvetica, sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f3e8ff,
                    #ffffff
                );

            min-height: 100vh;
        }

        /* HEADER */

        header{

            background:
                linear-gradient(
                    to right,
                    #d8b4fe,
                    #c77dff
                );

            padding: 25px 50px;

            color: black;

            box-shadow:
                0px 4px 15px rgba(0,0,0,0.1);
        }

        .logo-area{

            display: flex;

            align-items: center;

            gap: 18px;
        }

        .logo-img{

            width: 85px;

            height: 85px;

            object-fit: contain;

            background: white;

            padding: 8px;

            border-radius: 18px;

            box-shadow:
                0px 3px 10px rgba(0,0,0,0.15);
        }

        .logo-texto h1{

            font-size: 38px;
        }

        .logo-texto p{

            margin-top: 5px;

            font-size: 15px;
        }

        /* CONTAINER */

        .container{

            width: 92%;

            margin: auto;

            margin-top: 40px;
        }

        /* HERO */

        .hero{

            text-align: center;

            margin-bottom: 45px;
        }

        .hero-icon{

            width: 110px;

            height: 110px;

            margin: auto;

            background: white;

            border-radius: 50%;

            display: flex;

            justify-content: center;

            align-items: center;

            box-shadow:
                0px 5px 20px rgba(0,0,0,0.08);
        }

        .hero-icon img{

            width: 65px;

            height: 65px;

            object-fit: contain;
        }

        .hero h2{

            margin-top: 18px;

            font-size: 45px;

            color: #111;
        }

        .hero p{

            margin-top: 12px;

            color: #666;

            font-size: 18px;
        }

        /* BARRA */

        .barra-acoes{

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 35px;

            flex-wrap: wrap;

            gap: 20px;
        }

        .pesquisa-form{

            display: flex;

            gap: 10px;
        }

        .pesquisa-form input{

            width: 320px;

            padding: 15px 18px;

            border: none;

            border-radius: 12px;

            background: white;

            box-shadow:
                0px 3px 12px rgba(0,0,0,0.08);

            font-size: 15px;
        }

        .grupo-botoes{

            display: flex;

            gap: 15px;
        }

        .botao{

            background:
                linear-gradient(
                    to right,
                    #c77dff,
                    #9333ea
                );

            color: white;

            padding: 14px 22px;

            border-radius: 12px;

            text-decoration: none;

            border: none;

            font-weight: bold;

            cursor: pointer;

            transition: 0.3s;
        }

        .botao:hover{

            transform: translateY(-3px);
        }

        .botao-secundario{

            background: white;

            color: #9333ea;

            padding: 14px 22px;

            border-radius: 12px;

            text-decoration: none;

            font-weight: bold;

            border: 2px solid #d8b4fe;

            transition: 0.3s;
        }

        .botao-secundario:hover{

            background: #f3e8ff;
        }

        /* TABELA */

        table{

            width: 100%;

            border-collapse: collapse;

            background: white;

            border-radius: 18px;

            overflow: hidden;

            box-shadow:
                0px 8px 25px rgba(0,0,0,0.08);
        }

        th{

            background:
                linear-gradient(
                    to right,
                    #d8b4fe,
                    #c77dff
                );

            color: black;

            padding: 20px;

            font-size: 17px;
        }

        td{

            padding: 18px;

            text-align: center;

            border-bottom: 1px solid #eee;
        }

        tr:hover{

            background-color: #faf5ff;
        }

        /* BOT�ES */

        .acoes{

            display: flex;

            justify-content: center;

            gap: 10px;
        }

        .btn-editar{

            background-color: #3b82f6;

            color: white;

            padding: 8px 14px;

            border-radius: 8px;

            text-decoration: none;

            font-size: 14px;

            transition: 0.3s;
        }

        .btn-editar:hover{

            background-color: #2563eb;
        }

        .btn-excluir{

            background-color: #ef4444;

            color: white;

            padding: 8px 14px;

            border-radius: 8px;

            text-decoration: none;

            font-size: 14px;

            transition: 0.3s;
        }

        .btn-excluir:hover{

            background-color: #dc2626;
        }

        /* FOOTER */

        footer{

            margin-top: 50px;

            background: #111;

            color: white;

            text-align: center;

            padding: 22px;

            font-size: 15px;
        }

    </style>

</head>

<body>

    <header>

        <div class="logo-area">

            <img src="img/logo.png"
                 class="logo-img">

            <div class="logo-texto">

                <h1>TechStock Inform�tica</h1>

                <p>
                    Sistema de Gerenciamento de Estoque
                </p>

            </div>

        </div>

    </header>

    <div class="container">

        <!-- HERO -->

        <div class="hero">

            <div class="hero-icon">

                <img src="img/logo.png">

            </div>

            <h2>
                Controle de Estoque
            </h2>

            <p>
                Gerencie todos os produtos da TechStock
            </p>

        </div>

        <!-- BARRA -->

        <div class="barra-acoes">

            <form method="get"
                  class="pesquisa-form">

                <input type="text"
                       name="pesquisa"
                       placeholder="Pesquisar produto...">

                <button type="submit"
                        class="botao">

                    Pesquisar

                </button>

            </form>

            <div class="grupo-botoes">

                <a class="botao"
                   href="cadastroProduto.jsp">

                    + Novo Produto

                </a>

                <a class="botao-secundario"
                   href="index.jsp">

                    Home

                </a>

            </div>

        </div>

        <!-- TABELA -->

        <table>

            <tr>

                <th>ID</th>

                <th>Nome</th>

                <th>Categoria</th>

                <th>Quantidade</th>

                <th>Pre�o</th>

                <th style="width: 220px;">

                    A��es

                </th>

            </tr>

            <%

                for(Produto p : lista){

            %>

            <tr>

                <td>
                    <%= p.getId() %>
                </td>

                <td>
                    <%= p.getNome() %>
                </td>

                <td>
                    <%= p.getCategoria() %>
                </td>

                <td>
                    <%= p.getQuantidade() %>
                </td>

                <td>
                    R$ <%= p.getPreco() %>
                </td>

                <td>

                    <div class="acoes">

                        <a href="editarProduto.jsp?id=<%= p.getId() %>"
                           class="btn-editar">

                            Editar

                        </a>

                        <a href="excluirProduto.jsp?id=<%= p.getId() %>"
                           class="btn-excluir">

                            Excluir

                        </a>

                    </div>

                </td>

            </tr>

            <%

                }

            %>

        </table>

    </div>

    <footer>

        Desenvolvido por Hayyra Eduarda |
        Sistema MVC Java Web

    </footer>

</body>

</html>