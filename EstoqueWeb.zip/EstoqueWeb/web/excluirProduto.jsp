<%@page import="controller.CProduto"%>

<%

    int id =
            Integer.parseInt(
                request.getParameter("id")
            );

    CProduto controller =
            new CProduto();

    controller.excluir(id);

    response.sendRedirect("estoque.jsp");

%>