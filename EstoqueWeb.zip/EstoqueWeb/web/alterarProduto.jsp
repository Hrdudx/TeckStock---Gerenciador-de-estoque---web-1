<%@page import="model.Produto"%>
<%@page import="controller.CProduto"%>

<%

    Produto p = new Produto();

    p.setId(
        Integer.parseInt(
            request.getParameter("id")
        )
    );

    p.setNome(
        request.getParameter("nome")
    );

    p.setCategoria(
        request.getParameter("categoria")
    );

    p.setQuantidade(
        Integer.parseInt(
            request.getParameter("quantidade")
        )
    );

    p.setPreco(
        Double.parseDouble(
            request.getParameter("preco")
        )
    );

    CProduto controller =
            new CProduto();

    controller.alterar(p);

    response.sendRedirect("estoque.jsp");

%>