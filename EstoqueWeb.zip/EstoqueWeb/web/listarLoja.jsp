<%@page import="java.util.ArrayList"%>
<%@page import="model.Loja"%>
<%@page import="controller.CLoja"%>

<%

    CLoja controller =
            new CLoja();

    ArrayList<Loja> lista =
            controller.listar();

%>

<!DOCTYPE html>

<html>

<head>

    <title>Lista de Lojas</title>

    <style>

        body{
            font-family: Arial;
            background:#f4f4f4;
        }

        table{

            width:80%;

            margin:auto;

            margin-top:50px;

            border-collapse: collapse;

            background:white;
        }

        th{

            background:#c77dff;

            padding:15px;
        }

        td{

            padding:12px;

            text-align:center;

            border-bottom:1px solid #ddd;
        }

        h1{

            text-align:center;

            margin-top:40px;
        }

        .botao{

            display:block;

            width:220px;

            margin:auto;

            margin-top:30px;

            text-align:center;

            padding:14px;

            background:#9333ea;

            color:white;

            text-decoration:none;

            border-radius:10px;
        }

    </style>

</head>

<body>

<h1>Lojas Cadastradas</h1>

<a class="botao"
   href="cadastroLoja.jsp">

    + Nova Loja

</a>

<table>

<tr>

    <th>ID</th>
    <th>Nome</th>
    <th>Cidade</th>
    <th>Gerente</th>
    <th>Ativa</th>

</tr>

<%

    for(Loja l : lista){

%>

<tr>

    <td><%= l.getId() %></td>

    <td><%= l.getNome() %></td>

    <td><%= l.getCidade() %></td>

    <td><%= l.getGerente() %></td>

    <td><%= l.isAtiva() %></td>

</tr>

<%

    }

%>

</table>

</body>

</html>