<%@page import="model.Loja"%>
<%@page import="controller.CLoja"%>

<%

    Loja l = new Loja();

    l.setNome(
        request.getParameter("nome")
    );

    l.setCidade(
        request.getParameter("cidade")
    );

    l.setGerente(
        request.getParameter("gerente")
    );

    l.setAtiva(
        Boolean.parseBoolean(
            request.getParameter("ativa")
        )
    );

    CLoja controller =
            new CLoja();

    controller.inserir(l);

    response.sendRedirect("listarLoja.jsp");

%>