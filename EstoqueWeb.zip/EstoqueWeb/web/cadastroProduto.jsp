<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="Content-Type"
          content="text/html; charset=UTF-8">

    <title>Cadastrar Produto</title>

    <style>

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body{

            font-family: Arial, Helvetica, sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f3e8ff,
                    #ffffff
                );

            min-height: 100vh;
        }

        header{

            background: rgba(255,255,255,0.7);

            backdrop-filter: blur(10px);

            padding: 20px 50px;

            box-shadow:
                0px 4px 15px rgba(0,0,0,0.08);
        }

        header h1{

            font-size: 35px;
        }

        .container{

            width: 450px;

            margin: auto;

            margin-top: 60px;

            background: rgba(255,255,255,0.85);

            backdrop-filter: blur(10px);

            padding: 40px;

            border-radius: 25px;

            box-shadow:
                0px 10px 30px rgba(0,0,0,0.1);
        }

        .container h2{

            text-align: center;

            margin-bottom: 30px;

            font-size: 30px;
        }

        label{

            display: block;

            margin-top: 15px;

            font-weight: bold;
        }

        input{

            width: 100%;

            padding: 14px;

            margin-top: 8px;

            border: 1px solid #ddd;

            border-radius: 12px;

            font-size: 15px;
        }

        input:focus{

            outline: none;

            border-color: #c77dff;
        }

        .botao{

            width: 100%;

            margin-top: 30px;

            padding: 15px;

            border: none;

            border-radius: 12px;

            background:
                linear-gradient(
                    to right,
                    #c77dff,
                    #9333ea
                );

            color: white;

            font-size: 16px;

            font-weight: bold;

            cursor: pointer;

            transition: 0.3s;
        }

        .botao:hover{

            transform: scale(1.03);
        }

        .voltar{

            display: inline-block;

            margin-top: 20px;

            text-decoration: none;

            color: #9333ea;

            font-weight: bold;
        }

    </style>

</head>

<body>

    <header>

        <h1>TechStock Informática</h1>

    </header>

    <div class="container">

        <h2>Cadastrar Produto</h2>

        <form action="salvarProduto.jsp"
              method="post">

            <label>Nome do Produto</label>

            <input type="text"
                   name="nome"
                   required>

            <label>Categoria</label>

            <input type="text"
                   name="categoria"
                   required>

            <label>Quantidade</label>

            <input type="number"
                   name="quantidade"
                   required>

            <label>Preço</label>

            <input type="number"
                   step="0.01"
                   name="preco"
                   required>

            <button class="botao"
                    type="submit">

                Salvar Produto

            </button>

        </form>

        <a class="voltar"
           href="estoque.jsp">

            ← Voltar ao Estoque

        </a>

    </div>

</body>

</html>