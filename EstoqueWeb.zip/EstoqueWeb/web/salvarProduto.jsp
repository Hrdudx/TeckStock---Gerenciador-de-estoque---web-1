<%@page import="model.Produto"%>
<%@page import="controller.CProduto"%>

<%

    String nome =
            request.getParameter("nome");

    String categoria =
            request.getParameter("categoria");

    int quantidade =
            Integer.parseInt(
                request.getParameter("quantidade")
            );

    double preco =
            Double.parseDouble(
                request.getParameter("preco")
            );

    Produto p = new Produto();

    p.setNome(nome);

    p.setCategoria(categoria);

    p.setQuantidade(quantidade);

    p.setPreco(preco);

    CProduto controller =
            new CProduto();

    controller.inserir(p);

    response.sendRedirect("estoque.jsp");

%>