<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="Content-Type"
          content="text/html; charset=UTF-8">

    <title>TechStock Informática</title>

    <style>

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body{

            font-family: Arial, Helvetica, sans-serif;

            background:
                linear-gradient(
                    135deg,
                    #f3e8ff,
                    #ffffff
                );

            min-height: 100vh;
        }

        /* HEADER */

        header{

            width: 100%;

            background: rgba(255,255,255,0.7);

            backdrop-filter: blur(10px);

            padding: 20px 60px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            box-shadow:
                0px 4px 15px rgba(0,0,0,0.08);
        }

        .logo-area{

            display: flex;

            align-items: center;

            gap: 15px;
        }

        .logo{

            width: 70px;
            height: 70px;

            border-radius: 50%;

            background-color: #c77dff;

            display: flex;

            justify-content: center;

            align-items: center;

            font-size: 35px;
        }

        .titulo h1{

            font-size: 34px;

            color: #111;
        }

        .titulo p{

            color: #666;

            margin-top: 5px;
        }

        /* HERO */

        .hero{

            text-align: center;

            margin-top: 70px;
        }

        .hero h2{

            font-size: 50px;

            color: #111;
        }

        .hero p{

            margin-top: 15px;

            font-size: 18px;

            color: #555;
        }

        /* CARDS */

        .container{

            width: 90%;

            margin: auto;

            margin-top: 70px;

            display: flex;

            justify-content: center;

            gap: 50px;

            flex-wrap: wrap;
        }

        .card{

            width: 360px;

            background: rgba(255,255,255,0.8);

            backdrop-filter: blur(12px);

            border-radius: 25px;

            padding: 35px;

            box-shadow:
                0px 10px 30px rgba(0,0,0,0.1);

            transition: 0.3s;

            position: relative;

            overflow: hidden;
        }

        .card:hover{

            transform: translateY(-12px);
        }

        .card::before{

            content: "";

            position: absolute;

            width: 180px;
            height: 180px;

            background: #e9d5ff;

            border-radius: 50%;

            top: -60px;
            right: -60px;
        }

        .icone{

            font-size: 65px;

            position: relative;

            z-index: 2;
        }

        .card h3{

            margin-top: 25px;

            font-size: 32px;

            position: relative;

            z-index: 2;
        }

        .card p{

            margin-top: 15px;

            color: #555;

            line-height: 1.6;

            position: relative;

            z-index: 2;
        }

        .status{

            margin-top: 20px;

            display: inline-block;

            background-color: #dcfce7;

            color: #166534;

            padding: 8px 15px;

            border-radius: 20px;

            font-size: 14px;

            position: relative;

            z-index: 2;
        }

        .botao{

            display: inline-block;

            margin-top: 30px;

            background:
                linear-gradient(
                    to right,
                    #c77dff,
                    #9333ea
                );

            color: white;

            padding: 14px 28px;

            border-radius: 12px;

            text-decoration: none;

            font-weight: bold;

            transition: 0.3s;

            position: relative;

            z-index: 2;
        }

        .botao:hover{

            transform: scale(1.05);
        }

        /* FOOTER */

        footer{

            margin-top: 100px;

            background-color: #111;

            color: white;

            text-align: center;

            padding: 25px;
        }

    </style>

</head>

<body>

    <header>

        <div class="logo-area">

            <div class="logo">
                💻
            </div>

            <div class="titulo">

                <h1>TechStock</h1>

                <p>Gerenciamento Inteligente de Estoque</p>

            </div>

        </div>

    </header>

    <section class="hero">

        <h2>Controle Completo do Estoque</h2>

        <p>
            Sistema moderno para gerenciamento
            das unidades da loja.
        </p>

    </section>

    <div class="container">

        <!-- LOJA 1 -->

        <div class="card">

            <div class="icone">
                🖥️
            </div>

            <h3>Loja Centro</h3>

            <p>

                Unidade principal da TechStock
                especializada em periféricos,
                notebooks e computadores.

            </p>

            <div class="status">
                Loja ativa
            </div>

            <br>

            <a class="botao"
               href="estoque.jsp">

                Visualizar Estoque

            </a>

        </div>

        <!-- LOJA 2 -->

        <div class="card">

            <div class="icone">
                🛒
            </div>

            <h3>Loja Shopping</h3>

            <p>

                Unidade localizada no shopping,
                focada em acessórios gamers
                e produtos premium.

            </p>

            <div class="status">
                Loja ativa
            </div>

            <br>

            <a class="botao"
               href="estoque.jsp">

                Visualizar Estoque

            </a>

        </div>

    </div>

    <footer>

        Desenvolvido por Hayyra Eduarda |
        Sistema MVC Java Web

    </footer>

</body>

</html>