<%@page import="java.util.ArrayList"%>
<%@page import="model.Produto"%>
<%@page import="controller.CProduto"%>

<%

    int id =
            Integer.parseInt(
                request.getParameter("id")
            );

    CProduto controller =
            new CProduto();

    ArrayList<Produto> lista =
            controller.listar();

    Produto produto = null;

    for(Produto p : lista){

        if(p.getId() == id){

            produto = p;

        }

    }

%>

<!DOCTYPE html>

<html>

<head>

    <title>Editar Produto</title>

    <style>

        body{
            font-family: Arial;
            background:#f3e8ff;
        }

        .container{

            width:400px;

            margin:auto;

            margin-top:60px;

            background:white;

            padding:30px;

            border-radius:15px;
        }

        input{

            width:100%;

            padding:12px;

            margin-top:10px;

            margin-bottom:15px;
        }

        button{

            width:100%;

            padding:14px;

            background:#9333ea;

            color:white;

            border:none;

            border-radius:10px;
        }

    </style>

</head>

<body>

<div class="container">

<h2>Editar Produto</h2>

<form action="alterarProduto.jsp"
      method="post">

    <input type="hidden"
           name="id"
           value="<%= produto.getId() %>">

    <input type="text"
           name="nome"
           value="<%= produto.getNome() %>">

    <input type="text"
           name="categoria"
           value="<%= produto.getCategoria() %>">

    <input type="number"
           name="quantidade"
           value="<%= produto.getQuantidade() %>">

    <input type="number"
           step="0.01"
           name="preco"
           value="<%= produto.getPreco() %>">

    <button type="submit">

        Salvar Altera��es

    </button>

</form>

</div>

</body>

</html>