<!DOCTYPE html>

<html>

<head>

    <title>Cadastrar Loja</title>

    <style>

        body{
            font-family: Arial;
            background:#f3e8ff;
        }

        .container{

            width:400px;

            margin:auto;

            margin-top:60px;

            background:white;

            padding:30px;

            border-radius:15px;
        }

        input{

            width:100%;

            padding:12px;

            margin-top:10px;

            margin-bottom:15px;
        }

        button{

            width:100%;

            padding:14px;

            background:#9333ea;

            color:white;

            border:none;

            border-radius:10px;
        }

    </style>

</head>

<body>

<div class="container">

<h2>Cadastrar Loja</h2>

<form action="salvarLoja.jsp"
      method="post">

    <input type="text"
           name="nome"
           placeholder="Nome da loja">

    <input type="text"
           name="cidade"
           placeholder="Cidade">

    <input type="text"
           name="gerente"
           placeholder="Gerente">

    <input type="text"
           name="ativa"
           placeholder="true ou false">

    <button type="submit">

        Salvar Loja

    </button>

</form>

</div>

</body>

</html>